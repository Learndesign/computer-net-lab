chmod +x scripts/disable_offloading.sh
chmod +x scripts/disable_ipv6.sh
chmod +x scripts/disable_icmp.sh
chmod +x scripts/disable_ip_forward.sh
chmod +x scripts/disable_arp.sh
chmod +x scripts/disable_tcp_rst.sh